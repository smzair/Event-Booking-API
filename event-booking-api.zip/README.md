# Event Booking API

Project overview and setup instructions will go here.